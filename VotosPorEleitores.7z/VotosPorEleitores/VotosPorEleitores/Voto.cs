﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VotosPorEleitores
{
    public class Voto
    {
        public readonly int Valido;
        public readonly int Branco;
        public readonly int Nulo;
        public readonly int TotalDeEleitores;

        public Voto()
        {
            Valido = 800;
            Branco = 150;
            Nulo = 50;
            TotalDeEleitores = new Eleitor().totalDeEleitores;
        }


        public Voto(int valido, int branco, int nulo, int totalDeEleitores)
        {
            Valido = valido;
            Branco = branco;
            Nulo = nulo;
            TotalDeEleitores = new Eleitor(totalDeEleitores).totalDeEleitores;

        }
        public double PorcentagemVotoValido() => Valido / TotalDeEleitores;

        public double PorcentagemVotoBranco() => Branco / TotalDeEleitores;

        public double PorcentagemVotoNulo() => Nulo / TotalDeEleitores;

        public double PorcentagemPropoporcional() => (((Nulo / 12) * 3) + TotalDeEleitores) / (((TotalDeEleitores / 12) * 3) + TotalDeEleitores);

    }
}
