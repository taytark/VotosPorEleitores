﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VotosPorEleitores
{
    class Program
    {
        static void Main(string[] args)
        {
            var voto = new Voto();

            Console.WriteLine("Votação");

            Console.WriteLine($"Porcentagem dos votos válidos: {voto.PorcentagemVotoValido()}");
            Console.WriteLine($"Porcentagem dos votos brancos: {voto.PorcentagemVotoBranco()}");
            Console.WriteLine($"Porcentagem dos votos Nulos: {voto.PorcentagemVotoNulo()}");
            //Console.WriteLine($"Porcentagem dos proporcionais ao aumento de 3/12 de eleitores e nulos: {Voto.PorcentagemProporcional()}");
            Console.ReadLine();
        }
    }
}
